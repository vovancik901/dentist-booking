import {NgModule} from '@angular/core';
import {PreloadAllModules, RouterModule, Routes} from '@angular/router';

const appRoutes: Routes = [
  {path: '', redirectTo: '/booking', pathMatch: 'full'},
  {
    path: 'booking',
    loadChildren: () => import('./shared/components/booking/booking.module').then(m => m.BookingModule)
  },
  {
    path: 'doctors',
    loadChildren: () => import('./shared/components/doctors/doctors.module').then(m => m.DoctorsModule)
  },
  {
    path: 'procedures',
    loadChildren: () => import('./shared/components/procedures/procedures.module').then(m => m.ProceduresModule)
  },
  {
    path: 'booking-view',
    loadChildren: () => import('./shared/components/booking-view/booking-view.module').then(m => m.BookingViewModule)
  },
  {
    path: '**', redirectTo: '/booking', pathMatch: 'full'
  }
];


@NgModule({
  imports: [RouterModule.forRoot(appRoutes, {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModel {

}
