import {ChangeDetectorRef, Component, OnDestroy, OnInit} from '@angular/core';
import {ButtonModule} from 'primeng/button';
import {MessageService} from 'primeng/api';
import {filter, takeWhile} from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dentist-booking';
}
