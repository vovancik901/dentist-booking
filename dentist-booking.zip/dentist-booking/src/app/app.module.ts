import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {AppComponent} from './app.component';
import {ButtonModule} from 'primeng/button';
import {HeaderComponent} from './layout/header/header.component';
import {MainComponent} from './layout/main/main.component';
import {ContentComponent} from './layout/content/content.component';
import {AppRoutingModel} from './app-routing.model';
import {FieldsetModule} from 'primeng/fieldset';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {StoreModule} from '@ngrx/store';
import * as fromApp from './store/app.reducer';
import {EffectsModule} from '@ngrx/effects';
import {DoctorsEffects} from './shared/components/doctors/store/doctors.effects';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {environment} from '../environments/environment';
import {HttpClientModule} from '@angular/common/http';
import {ProcedureEffect} from './shared/components/procedures/store/procedures.effects';
import {HttpService} from './shared/services/http-service';
import {DoctorsModel} from './shared/components/doctors/doctors-model';
import {ProcedureModel} from './shared/components/procedures/procedure-model';
import {DropDownUtility} from './shared/services/util';
import {DialogService, DynamicDialogRef, MessageService} from 'primeng/api';
import {ToastModule} from 'primeng/toast';
import {BookingViewEffect} from './shared/components/booking-view/store/booking-view.effect';
import {BookingViewModel} from './shared/components/booking-view/booking-view-model';
import {AuthModule} from './shared/components/auth/auth.module';
import {AuthComponent} from './shared/components/auth/auth.component';
import {DynamicDialogModule} from 'primeng/dynamicdialog';
import {AuthModel} from './shared/components/auth/auth.model';
import {AuthEffects} from './shared/components/auth/store/auth.effects';
import {DropdownDirective} from './shared/services/dropdown.directive';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainComponent,
    ContentComponent,
    DropdownDirective,

  ],
  imports: [
    DynamicDialogModule,
    BrowserModule,
    ButtonModule,
    HttpClientModule,
    ToastModule,
    AuthModule,
    AppRoutingModel,
    FieldsetModule,
    BrowserAnimationsModule,
    NgbModule,
    StoreModule.forRoot(fromApp.appReducer),
    EffectsModule.forRoot([DoctorsEffects, ProcedureEffect, BookingViewEffect, AuthEffects]),
    StoreDevtoolsModule.instrument({logOnly: environment.production}),
  ],
  providers: [HttpService,
    DoctorsModel,
    ProcedureModel,
    DropDownUtility,
    MessageService,
    BookingViewModel,
    DialogService,
    AuthModel,
    DynamicDialogRef],
  bootstrap: [AppComponent],
  entryComponents: [AuthComponent]
})
export class AppModule {
}
