import {Component, OnInit} from '@angular/core';
import {AuthComponent} from '../../shared/components/auth/auth.component';
import {DialogService} from 'primeng/api';
import {AuthModel} from '../../shared/components/auth/auth.model';
import {Store} from '@ngrx/store';
import * as fromApp from '../../store/app.reducer';
import * as AuthAction from '../../shared/components/auth/store/auth.actions';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: 'header.component.html',
  styleUrls: ['header.component.scss']
})
export class HeaderComponent implements OnInit {
  constructor(public dialogService: DialogService,
              private authModel: AuthModel,
              public store: Store<fromApp.AppState>,
              private route: ActivatedRoute,
              private router: Router) {
  }

  showLoginPage() {
    const ref = this.dialogService.open(AuthComponent, {
      header: 'Enter your email and password',
      width: '40%',
      contentStyle: {'max-height': '350px', overflow: 'auto'}
    });
  }

  ngOnInit(): void {
    this.store.dispatch(new AuthAction.AutoLogin());
  }

  toAppointments() {
    this.router.navigate(['/booking-view']).then(r => console.log(r));
  }

  logOut() {
    this.authModel.logOut();
  }

}
