import {Component} from '@angular/core';
import {NgForm} from '@angular/forms';
import {User} from '../../models/user.model';
import {AuthModel} from './auth.model';

@Component({
  selector: 'app-auth',
  templateUrl: 'auth.component.html',
  styleUrls: ['auth.component.scss']
})

export class AuthComponent {
  constructor(private authModel: AuthModel) {
  }

  onSubmit(authForm: NgForm) {
    const formValue: User = authForm.value;
    this.authModel.login(formValue);
  }
}
