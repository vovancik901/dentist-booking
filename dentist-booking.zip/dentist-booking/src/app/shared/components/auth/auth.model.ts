import {Injectable} from '@angular/core';
import {select, Store} from '@ngrx/store';
import * as fromApp from '../../../store/app.reducer';
import {Observable} from 'rxjs';
import {getAuthEntities} from './store/auth.selector';
import * as AuthAction from './store/auth.actions';
import {User} from '../../models/user.model';

@Injectable()

export class AuthModel {
  user: Observable<any>;

  constructor(public store: Store<fromApp.AppState>) {
    this.user = this.store.pipe(select(getAuthEntities));
  }


  login(payload: User) {
    this.store.dispatch(new AuthAction.LoginStart(payload));
  }

  logOut() {
    this.store.dispatch(new AuthAction.LogOut());
  }
}
