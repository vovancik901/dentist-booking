import {Actions, Effect, ofType} from '@ngrx/effects';
import {DialogService, MessageService} from 'primeng/api';
import * as AuthActon from './auth.actions';
import {Injectable} from '@angular/core';
import {map} from 'rxjs/operators';
import {toPayload} from '../../../services/util';
import {isEqual} from 'lodash';
import {User} from '../../../models/user.model';
import {Router} from '@angular/router';

@Injectable()

export class AuthEffects {

  @Effect() userLogin = this.actions.pipe(
    ofType(AuthActon.LOGIN_START),
    map(toPayload),
    map((payload) => {
      // This is face login check
      const fakeAcc = {
        email: 'admin@admin.com',
        password: 'admin'
      };

      if (isEqual(payload, fakeAcc)) {
        this.dialogService.dialogComponentRef.destroy();
        this.messageService.add({severity: 'success', summary: 'Success', detail: 'You are welcome'});
        localStorage.setItem('userData', JSON.stringify(payload));
        return new AuthActon.LoginSuccess(payload);
      } else {
        this.messageService.add({severity: 'error', summary: 'Error Login', detail: 'Wrong email or password'});
        return new AuthActon.LoginFail();
      }
    })
  );

  @Effect({dispatch: false}) logOut = this.actions.pipe(
    ofType(AuthActon.LOGOUT),
    map(() => {
      this.messageService.add({severity: 'info', summary: 'Logout', detail: 'Bye'});
      localStorage.removeItem('userData');
      this.router.navigate(['/booking']).then(r => console.log(r));
    })
  );

  @Effect() autoLogin = this.actions.pipe(
    ofType(AuthActon.AUTO_LOGIN),
    map(() => {
      const userData: User = JSON.parse(localStorage.getItem('userData'));
      if (!userData) {
        return {type: 'DUMMY'};
      }
      return new AuthActon.LoginSuccess(userData);
    })
  );

  constructor(private actions: Actions,
              public dialogService: DialogService,
              private messageService: MessageService,
              private router: Router) {
  }
}
