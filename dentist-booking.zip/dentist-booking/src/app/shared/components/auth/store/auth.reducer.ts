import {User} from '../../../models/user.model';
import * as AuthAction from './auth.actions';

export interface State {
  user: User;
  authError: string;
  loading: boolean;
}

const initialState: State = {
  user: null,
  authError: null,
  loading: null
};

export function authReducer(state: State = initialState, action: AuthAction.AuthActions) {
  switch (action.type) {
    case AuthAction.LOGIN_START:
      return {
        ...state,
        authError: null,
        loading: true
      };

    case AuthAction.LOGIN_SUCCESS:
      const loginUser = new User(
        action.payload.email,
        action.payload.password);
      return {
        ...state,
        user: loginUser,
        loading: false
      };

    case AuthAction.LOGIN_FAIL:
      return {
        ...state,
        user: null,
        loading: false
      };

    case AuthAction.LOGOUT:
      return {
        ...state,
        user: null,
        loading: false
      };

    case AuthAction.AUTO_LOGIN:
      return {
        ...state,
        loading: true,
      };

    default:
      return state;
  }
}
