import {getAuthState} from '../../../../store/app.reducer';
import {createSelector} from '@ngrx/store';

export const getAuthEntities = createSelector(
  getAuthState,
  (state) => {
    return state.user;
  });
