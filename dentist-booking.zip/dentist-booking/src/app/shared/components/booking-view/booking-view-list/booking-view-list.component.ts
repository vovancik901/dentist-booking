import {Component, Input, OnInit} from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {Observable} from 'rxjs';
import {Doctor} from '../../../models/doctors.model';

@Component({
  selector: 'app-booking-view-list',
  templateUrl: 'booking-view-list.component.html',
  styleUrls: ['booking-view-list.component.scss'],
  animations: [
    trigger('rowExpansionTrigger', [
      state('void', style({
        transform: 'translateX(-10%)',
        opacity: 0
      })),
      state('active', style({
        transform: 'translateX(0)',
        opacity: 1
      })),
      transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
    ])
  ]
})


export class BookingViewListComponent implements OnInit {
  @Input() people: Doctor[];

  cols: any[];
  constructor() {
    console.log('PEOPLE', this.people);
  }

  ngOnInit(): void {

    this.cols = [
      { field: 'doctor', header: 'Doctor' },
      { field: 'procedure', header: 'Procedure' },
      { field: 'procedureStartDate', header: 'Date' },
      { field: 'booking', header: 'Name of Patient' }
    ];
  }
}
