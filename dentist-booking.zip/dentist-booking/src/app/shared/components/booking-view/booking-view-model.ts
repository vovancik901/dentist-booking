import {Injectable} from '@angular/core';
import {select, Store} from '@ngrx/store';
import * as fromApp from '../../../store/app.reducer';
import {Observable} from 'rxjs';
import {getBookingViewEntities} from './store/booking-view.selector';
import * as BookingViewActions from './store/booking-view.action';

@Injectable()

export class BookingViewModel {
  booking: Observable<any>;

  constructor(public store: Store<fromApp.AppState>) {
    this.booking = this.store.pipe(select(getBookingViewEntities));
  }

  getBookings() {
    this.store.dispatch(new BookingViewActions.GetBookings());
  }
}
