import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {BookingViewComponent} from './booking-view.component';
import {AuthGuard} from '../auth/auth.guard';

const router: Routes = [
  {path: '', component: BookingViewComponent, canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(router)],
  exports: [RouterModule]
})

export class BookingViewRoutingModule {
}
