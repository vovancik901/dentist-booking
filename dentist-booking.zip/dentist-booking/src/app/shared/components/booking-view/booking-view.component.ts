import {Component} from '@angular/core';
import {BookingViewModel} from './booking-view-model';

@Component({
  selector: 'app-booking-view',
  templateUrl: 'booking-view.component.html',
  styleUrls: ['booking-view.component.scss']
})


export class BookingViewComponent {


  constructor(public bookingViewModel: BookingViewModel) {
    this.bookingViewModel.getBookings();
  }

}
