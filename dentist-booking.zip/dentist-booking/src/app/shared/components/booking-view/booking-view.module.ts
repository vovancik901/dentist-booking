import {NgModule} from '@angular/core';
import {BookingViewComponent} from './booking-view.component';
import {CommonModule} from '@angular/common';
import {BookingViewRoutingModule} from './booking-view-routing.module';
import {BookingViewListComponent} from './booking-view-list/booking-view-list.component';
import {TableModule} from 'primeng/table';

@NgModule({
  declarations: [BookingViewComponent, BookingViewListComponent],
  imports: [CommonModule, BookingViewRoutingModule, TableModule]
})

export class BookingViewModule {

}
