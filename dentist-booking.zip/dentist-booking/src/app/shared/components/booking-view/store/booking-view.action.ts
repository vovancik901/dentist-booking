import {Action} from '@ngrx/store';
import {BookingViewModel} from '../../../models/booking-view.model';

export const GET_BOOKINGS = '[Booking-view] Get Bookings';
export const FETCH_BOOKINGS = '[Booking-view] Fetch Bookings';

export class GetBookings implements Action {
  readonly type = GET_BOOKINGS;
}

export class FetchBookings implements Action {
  readonly type = FETCH_BOOKINGS;
  constructor(public payload: BookingViewModel[]) {
  }
}

export type BookingViewAction = GetBookings | FetchBookings;
