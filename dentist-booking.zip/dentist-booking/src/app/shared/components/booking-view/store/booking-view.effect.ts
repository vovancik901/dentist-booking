import {Actions, Effect, ofType} from '@ngrx/effects';
import {HttpService} from '../../../services/http-service';
import {Injectable} from '@angular/core';
import * as BookingViewActions from './booking-view.action';
import {map, switchMap} from 'rxjs/operators';
import {BookingViewModel} from '../../../models/booking-view.model';

@Injectable()
export class BookingViewEffect {

  @Effect() bookingsGet = this.actions.pipe(
    ofType(BookingViewActions.GET_BOOKINGS),
    switchMap(() => {
      return this.httpService.getBookingDetails().pipe(
        map((res: BookingViewModel[]) => {
          console.log('Effect Res BookingView', res);
          return new BookingViewActions.FetchBookings(res);
        })
      );
    })
  );

  constructor(private actions: Actions,
              private httpService: HttpService) {
  }
}
