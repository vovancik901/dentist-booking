import {BookingViewModel} from '../../../models/booking-view.model';
import * as BookingViewActions from './booking-view.action';

export interface State {
  bookings: BookingViewModel[];
  bookingsError: string;
  loading: boolean;
}

const initialState: State = {
  bookings: null,
  bookingsError: null,
  loading: null
};

export function bookingsReducer(state: State = initialState, action: BookingViewActions.BookingViewAction) {
  switch (action.type) {
    case BookingViewActions.GET_BOOKINGS:
      return {
        ...state,
        loading: true
      };

    case BookingViewActions.FETCH_BOOKINGS:
      return {
        ...state,
        bookings: [...action.payload],
        loading: false
      };

    default:
      return state;
  }
}
