import {getBookingsState} from '../../../../store/app.reducer';
import {createSelector} from '@ngrx/store';

export const getBookingViewEntities = createSelector(
  getBookingsState,
  state => state.bookings
);
