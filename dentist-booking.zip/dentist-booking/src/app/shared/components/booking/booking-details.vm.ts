import {forEach} from 'lodash';
import {Injectable} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

export class BookingDetailsForm {
  procedureId: number = null;
  doctorId: number = null;
  procedureStartTime: Date = new Date();
  patientFullName: string = null;
  patientPhone: number = null;
  patientEmail: string = null;
  comment: string = null;

  constructor(options: { [p: string]: any } = {}) {
    this.setValues(options);
  }

  setValues(options = {}) {
    forEach(this, (val, key) => {
      this[key] = options[key] ? options[key] : this[key];
    });
  }
}

@Injectable()
export class BookingDetailsVm {
  formGroupOptions: { [key: string]: any[] };

  constructor(private fb: FormBuilder) {
    this.formGroupOptions = {
      procedureId: [null, [Validators.required]],
      doctorId: [null, [Validators.required]],
      patientEmail: ['', [Validators.email]],
      procedureStartTime: [new Date(), Validators.required],
      patientPhone: [null, Validators.required],
      patientFullName: [null, Validators.required],
      comment: ['']
    };
  }

  createBookingsDetails(options?): BookingDetailsForm {
    return new BookingDetailsForm(options);
  }

  createBookingDetailsForm(): FormGroup {
    const form = this.createBookingsDetails();
    form.setValues(this.formGroupOptions);

    return this.fb.group(form);
  }

  fromForm(details) {
    details.doctorId = details.doctorId.value;
    details.procedureId = details.procedureId.value;
    details.procedureStartTime =  details.procedureStartTime.getTime();

    return details;
  }

}
