import {Component, EventEmitter, Output} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {BookingDetailsVm} from '../booking-details.vm';
import {DoctorsModel} from '../../doctors/doctors-model';
import {ProcedureModel} from '../../procedures/procedure-model';
import {DropDownUtility, IDropDownItem} from '../../../services/util';
import {MessageService} from 'primeng/api';

@Component({
  selector: 'app-booking-details',
  templateUrl: 'booking-details.component.html',
  styleUrls: ['booking-details.component.scss']
})

export class BookingDetailsComponent {

  @Output() save = new EventEmitter();

  bookingGroup: FormGroup;
  procedures: IDropDownItem[];

  constructor(private bookingVm: BookingDetailsVm,
              private doctorsModel: DoctorsModel,
              public procedureModel: ProcedureModel,
              private dropdownUtility: DropDownUtility,
              private messageService: MessageService) {
    this.bookingGroup = this.bookingVm.createBookingDetailsForm();
    this.doctorsModel.getDoctors();
    this.procedureModel.getProcedures();
  }

  onSubmit() {
      if (this.bookingGroup.valid) {
        this.save.emit(this.bookingGroup.getRawValue());
        this.bookingGroup.reset();
      } else {
        this.messageService.add({severity: 'warn', summary: 'Warn Message', detail: 'Please complete this form correctly'});
      }
  }

}
