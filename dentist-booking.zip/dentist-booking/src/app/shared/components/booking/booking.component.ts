import {Component} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {BookingDetailsVm} from './booking-details.vm';
import {BookingModel} from './booking.model';

@Component({
  selector: 'app-booking',
  templateUrl: 'booking.component.html',
  styleUrls: ['booking.component.scss']
})

export class BookingComponent {
  bookingGroup: FormGroup;

  constructor(private bookingVm: BookingDetailsVm,
              private bookingModel: BookingModel) {
    this.bookingGroup = this.bookingVm.createBookingDetailsForm();
  }

  onSave(form) {
    const details = this.bookingVm.fromForm(form);

    this.bookingModel.addBooking(details);
  }

}
