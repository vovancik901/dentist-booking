import {Injectable} from '@angular/core';
import {HttpService} from '../../services/http-service';
import {MessageService} from 'primeng/api';

@Injectable()
export class BookingModel {
  constructor(public httpService: HttpService,
              private messageService: MessageService) {
  }

  addBooking(payload) {
    this.httpService.addBooking(payload).subscribe(
      (res) => {
        this.messageService.add({
          severity: 'success', summary: 'Success', detail: 'Request has been sent'
        });
      },
      (error: Error) => {
        this.messageService.add({
          severity: 'error', summary: error.name, detail: error.message
        });
      }
    );
  }
}
