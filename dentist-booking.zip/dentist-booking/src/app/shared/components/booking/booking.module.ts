import {NgModule} from '@angular/core';
import {BookingComponent} from './booking.component';
import {BookingRoutingModule} from './booking-routing.module';
import {CardModule} from 'primeng/card';
import {ButtonModule} from 'primeng/button';
import {CommonModule} from '@angular/common';
import {CalendarModule} from 'primeng/calendar';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BookingDetailsVm} from './booking-details.vm';
import {BookingDetailsComponent} from './booking-details/booking-details.component';
import {DropdownModule} from 'primeng/dropdown';
import {BookingModel} from './booking.model';

@NgModule({
  declarations: [BookingComponent, BookingDetailsComponent],
  imports: [
    BookingRoutingModule,
    CardModule,
    ButtonModule,
    CommonModule,
    CalendarModule,
    ReactiveFormsModule,
    FormsModule,
    DropdownModule,

  ],
  providers: [BookingDetailsVm, BookingModel],
  exports: []
})
export class BookingModule {


}
