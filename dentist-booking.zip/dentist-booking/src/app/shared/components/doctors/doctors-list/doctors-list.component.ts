import {Component, Input} from '@angular/core';
import {Doctor} from '../../../models/doctors.model';

@Component({
  selector: 'app-doctors-list',
  templateUrl: 'doctors-list.component.html',
  styleUrls: ['doctors-list.component.scss']
})
export class DoctorsListComponent {
  @Input() doctor: Doctor;
  constructor() {
  }
}
