import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';
import {select, Store} from '@ngrx/store';
import * as fromApp from '../../../store/app.reducer';
import {getDoctorsEntices} from './store/doctors.selector';
import * as DoctorsActions from './store/doctors.actions';
import {getDoctorsState} from '../../../store/app.reducer';
import {map} from 'rxjs/operators';
import {DropDownUtility} from '../../services/util';

@Injectable()
export class DoctorsModel {
  doctors: Observable<any>;
  test: Observable<any>;
  doctorsDropdown: Observable<any>;

  constructor(public store: Store<fromApp.AppState>,
              private dropdownUtility: DropDownUtility) {
    this.doctors = this.store.pipe(select(getDoctorsEntices));
    this.test = this.store.pipe(select(getDoctorsState));
    this.doctorsDropdown = this.doctors.pipe(
      map(entities => {
        return this.dropdownUtility.buildDropDownList(entities, {
          label: 'name',
          value: 'id'
        });
      })
    );
  }

  getDoctors() {
    this.store.dispatch(new DoctorsActions.GetDoctors());
  }
}
