import {Component} from '@angular/core';
import {Store} from '@ngrx/store';
import * as fromApp from '../../../store/app.reducer';
import {DoctorsModel} from './doctors-model';

@Component({
  selector: 'app-doctors',
  templateUrl: 'doctors.component.html',
  styleUrls: ['doctors.component.scss']
})
export class DoctorsComponent {
  constructor(private store: Store<fromApp.AppState>,
              private doctorsModel: DoctorsModel) {
    this.doctorsModel.getDoctors();
  }

}
