import {NgModule} from '@angular/core';
import {DoctorsComponent} from './doctors.component';
import {DoctorsRoutingModule} from './doctors-routing.module';
import {DoctorsListComponent} from './doctors-list/doctors-list.component';
import {CommonModule} from '@angular/common';
import {CardModule} from 'primeng/card';
import {ButtonModule} from 'primeng/button';

@NgModule({
  declarations: [DoctorsComponent, DoctorsListComponent],
  imports: [DoctorsRoutingModule, CommonModule, CardModule, ButtonModule]
})
export class DoctorsModule {

}
