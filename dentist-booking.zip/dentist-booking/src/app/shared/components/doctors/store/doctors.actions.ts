import {Action} from '@ngrx/store';
import {Doctor} from '../../../models/doctors.model';

export const GET_DOCTORS = '[Doctors] Get Doctors';
export const FETCH_DOCTORS = '[Doctors] Fetch Doctors';
export const GET_DOCTORS_FAIL = '[Doctors] Get Doctors Fail';

export class GetDoctors implements Action {
  readonly type = GET_DOCTORS;
  constructor() {}
}

export class FetchDoctors implements Action {
  readonly type = FETCH_DOCTORS;
  constructor(public payload: Doctor[]) {}
}

export class GetDoctorsFail implements Action {
  readonly type = GET_DOCTORS_FAIL;
}


export type DoctorsActions = GetDoctors | FetchDoctors | GetDoctorsFail;
