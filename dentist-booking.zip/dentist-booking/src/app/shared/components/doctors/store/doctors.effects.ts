import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import * as DoctorAction from './doctors.actions';
import {catchError, map, switchMap} from 'rxjs/operators';
import {Doctor} from '../../../models/doctors.model';
import {HttpService} from '../../../services/http-service';
import {MessageService} from 'primeng/api';
import {of} from 'rxjs';

@Injectable()
export class DoctorsEffects {

  @Effect() doctorGet = this.actions.pipe(
    ofType(DoctorAction.GET_DOCTORS),
    switchMap(() => {
      return this.httpService.getDoctors().pipe(
        map((res: Doctor[]) => {
          return new DoctorAction.FetchDoctors(res);
        }),
        catchError((err: Error) => {
          this.messageService.add({severity: 'error', summary: err.name, detail: err.message});
          return of(new DoctorAction.GetDoctorsFail());
        })
      );
    })
  );


  constructor(private actions: Actions,
              private httpService: HttpService,
              private messageService: MessageService) {
  }
}
