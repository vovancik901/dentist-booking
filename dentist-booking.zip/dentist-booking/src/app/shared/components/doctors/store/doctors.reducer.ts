import {Doctor} from '../../../models/doctors.model';
import * as DoctorsAction from './doctors.actions';

export interface State {
  doctors: Doctor[];
  doctorError: string;
  loading: boolean;
}

const initialState: State = {
  doctors: null,
  doctorError: null,
  loading: null
};

export function doctorReducer(state: State = initialState, action: DoctorsAction.DoctorsActions) {
  switch (action.type) {
    case DoctorsAction.GET_DOCTORS:
      return {
        ...state,
        loading: true
      };

    case DoctorsAction.FETCH_DOCTORS:
      return {
        ...state,
        doctors: [...action.payload],
        loading: false
      };

    case DoctorsAction.GET_DOCTORS_FAIL:
      return {
        ...state,
        doctors: null,
        loading: false
      };

    default:
      return state;
  }
}
