import {getDoctorsState} from '../../../../store/app.reducer';
import {createSelector} from '@ngrx/store';

export const getDoctorsEntices = createSelector(
  getDoctorsState,
  (state) => state.doctors
);
