import {Component, Input} from '@angular/core';
import {Procedure} from '../../../models/procedure.model';

@Component({
  selector: 'app-procedure-list',
  templateUrl: 'procedure-list.component.html',
  styleUrls: ['procedure-list.component.scss']
})

export class ProcedureListComponent {
  @Input() procedures: Procedure[];

  constructor() {
  }
}
