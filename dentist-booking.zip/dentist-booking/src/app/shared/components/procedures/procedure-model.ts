import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';
import {select, Store} from '@ngrx/store';
import * as fromApp from '../../../store/app.reducer';
import {getProcedureEntities} from './store/procedure.selector';
import * as ProcedureActions from './store/procedures.action';
import {DropDownUtility} from '../../services/util';
import {map} from 'rxjs/operators';

@Injectable()
export class ProcedureModel {
  procedures: Observable<any>;
  proceduresDropdown: Observable<any>;

  constructor(public store: Store<fromApp.AppState>,
              private dropdownUtility: DropDownUtility) {
    this.procedures = this.store.pipe(select(getProcedureEntities));
    this.proceduresDropdown = this.procedures.pipe(
      map(entities => {
        return this.dropdownUtility.buildDropDownList(entities, {
          label: 'name',
          value: 'id'
        });
      })
    );
  }

  getProcedures() {
    this.store.dispatch(new ProcedureActions.GetProcedures());
  }

}
