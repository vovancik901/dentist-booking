import {Component} from '@angular/core';
import {ProcedureModel} from './procedure-model';

@Component({
  selector: 'app-services',
  templateUrl: 'procedures.component.html',
  styleUrls: ['procedures.component.scss']
})
export class ServiceComponent {
  constructor(public procedureModel: ProcedureModel) {
    this.procedureModel.getProcedures();
  }

}
