import {NgModule} from '@angular/core';
import {ServiceComponent} from './procedures.component';
import {ServicesRoutingModule} from './services-routing.module';
import {ProcedureListComponent} from './procedure-list/procedure-list.component';
import {CommonModule} from '@angular/common';

@NgModule({
  declarations: [ServiceComponent, ProcedureListComponent],
  imports: [ServicesRoutingModule, CommonModule]
})
export class ProceduresModule {

}
