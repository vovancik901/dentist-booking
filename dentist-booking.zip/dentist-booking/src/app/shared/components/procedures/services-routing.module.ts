import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ServiceComponent} from './procedures.component';

const router: Routes = [
  {path: '', component: ServiceComponent}
];

@NgModule({
  imports: [RouterModule.forChild(router)],
  exports: [RouterModule]
})
export class ServicesRoutingModule {
}
