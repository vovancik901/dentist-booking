import {getProcedureState} from '../../../../store/app.reducer';
import {createSelector} from '@ngrx/store';

export const getProcedureEntities = createSelector(
  getProcedureState,
  (state) => state.procedures
);

