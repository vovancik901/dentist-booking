import {Action} from '@ngrx/store';
import {Procedure} from '../../../models/procedure.model';

export const GET_PROCEDURE = '[Procedure] Get Procedures';
export const FETCH_PROCEDURE = '[Procedure] Fetch Procedures';
export const GET_PROCEDURE_FAIL = '[Procedure] Get Procedures Fail';

export class GetProcedures implements Action {
  readonly type = GET_PROCEDURE;

  constructor() {
  }
}

export class FetchProcedures implements Action {
  readonly type = FETCH_PROCEDURE;

  constructor(public payload: Procedure[]) {
  }
}

export class GetProcedureFail implements Action {
  readonly type = GET_PROCEDURE_FAIL;
}

export type ProcedureActions = GetProcedures | FetchProcedures | GetProcedureFail;
