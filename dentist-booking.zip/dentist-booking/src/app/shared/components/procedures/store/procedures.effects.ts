import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import * as ProcedureAction from './procedures.action';
import {catchError, map, switchMap} from 'rxjs/operators';
import {Procedure} from '../../../models/procedure.model';
import {HttpService} from '../../../services/http-service';
import {MessageService} from 'primeng/api';
import {of} from 'rxjs';

@Injectable()
export class ProcedureEffect {

  @Effect() procedureGet = this.actions.pipe(
    ofType(ProcedureAction.GET_PROCEDURE),
    switchMap(() => {
      return this.httpService.getProcedures().pipe(
        map((res: Procedure[]) => {
          return new ProcedureAction.FetchProcedures(res);
        }),
        catchError( (err: Error) => {
          this.messageService.add({severity: 'error', summary: err.name, detail: err.message});
          return of(new ProcedureAction.GetProcedureFail());
        })
      );
    })
  );

  constructor(private actions: Actions,
              private httpService: HttpService,
              private messageService: MessageService) {
  }

}
