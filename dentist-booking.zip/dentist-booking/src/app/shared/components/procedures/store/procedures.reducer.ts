import {Procedure} from '../../../models/procedure.model';
import * as ProcedureAction from './procedures.action';

export interface State {
  procedures: Procedure[];
  procedureError: string;
  loading: boolean;
}

const initialState: State = {
  procedures: null,
  procedureError: null,
  loading: null
};

export function procedureReducer(state: State = initialState, action: ProcedureAction.ProcedureActions) {
  switch (action.type) {
    case ProcedureAction.GET_PROCEDURE:
      return {
        ...state,
        loading: true
      };

    case ProcedureAction.FETCH_PROCEDURE:
      return {
        ...state,
        procedures: [...action.payload],
        loading: false
      };

    case ProcedureAction.GET_PROCEDURE_FAIL:
      return {
        ...state,
        procedures: null,
        loading: false
      };

    default:
      return state;
  }
}
