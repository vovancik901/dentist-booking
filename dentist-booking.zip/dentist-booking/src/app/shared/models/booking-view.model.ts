import {Procedure} from './procedure.model';
import {Doctor} from './doctors.model';

export class BookingViewModel {
  constructor(
  public id: number,
  public procedure: Procedure,
  public doctor: Doctor,
  public procedureStartDate: Date,
  public booking: any) {
  }
}
