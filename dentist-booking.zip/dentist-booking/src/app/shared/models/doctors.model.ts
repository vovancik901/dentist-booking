export class Doctor {
  constructor(
    public id: number,
    public name: string) {
  }
}
