import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';

@Injectable()

export class HttpService {
  urlProcedures = '/api/procedures';
  urlDoctors = '/api/doctors';
  urlBookingDetails = '/api/booking-details';
  urlPostBooking = '/api/bookings';
  urlDateAvailable = '/api/booking-details/is-available';

  constructor(private  http: HttpClient) {
  }

  getProcedures() {
    return this.http.get(this.urlProcedures);
  }

  getDoctors() {
    return this.http.get(this.urlDoctors);
  }

  getBookingDetails() {
    return this.http.get(this.urlBookingDetails);
  }

  addBooking(payload) {

    console.log('LOG FROM HHTP', payload);
    return this.http.post(this.urlPostBooking, payload
/*      {
        procedureId: 6,
        doctorId: 2,
        procedureStartTime: 1956812200001,
        patientFullName: 'Nick',
        patientPhone: 37388988766,
        patientEmail: 'valid@email.com',
        comment: 'Hello'
      }*/
    );
  }

  checkDateAvailable(payload) {
    return this.http.post(this.urlDateAvailable, payload);
  }

}
