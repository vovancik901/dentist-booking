import {Injectable} from '@angular/core';
import {map as _map} from 'lodash';
import {Action} from '@ngrx/store';
import * as moment from 'moment';

export interface IDropDownItem {
  label: string;
  value: string;
  defaultValue?: string;
}

@Injectable()
export class DropDownUtility {
  constructor() {
  }

  public buildDropDownList(res, mapping, defaultValue?) {
    const defaultVal = {label: '-', value: ''};
    const mapped = _map(res, (item) => {
      const newItem: { [key: string]: any } = {};
      for (const key of Object.keys(mapping)) {
        newItem[key] = item[mapping[key]];
      }
      return newItem;
    });

    if (defaultValue !== null) {
      defaultValue === undefined ? mapped.unshift(defaultVal) : mapped.unshift(defaultValue);
    }

    return mapped;
  }
}

export interface AppActions extends Action {
  payload?: any;
}

export function toPayload(action: AppActions): any {
  return action.payload;
}

export function dateToString(date: Date, format: string) {
  return moment(date).format(format);
}
