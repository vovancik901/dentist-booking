import {ActionReducerMap, createFeatureSelector} from '@ngrx/store';
import * as fromDoctors from '../shared/components/doctors/store/doctors.reducer';
import * as fromProcedures from '../shared/components/procedures/store/procedures.reducer';
import * as fromBookings from '../shared/components/booking-view/store/booking-view.reducer';
import * as fromAuth from '../shared/components/auth/store/auth.reducer';

export interface AppState {
  doctors: fromDoctors.State;
  procedures: fromProcedures.State;
  bookings: fromBookings.State;
  auth: fromAuth.State;
}

export const appReducer: ActionReducerMap<AppState> = {
  doctors: fromDoctors.doctorReducer,
  procedures: fromProcedures.procedureReducer,
  bookings: fromBookings.bookingsReducer,
  auth: fromAuth.authReducer
};

export const getProcedureState = createFeatureSelector<AppState['procedures']>('procedures');
export const getDoctorsState = createFeatureSelector<AppState['doctors']>('doctors');
export const getBookingsState = createFeatureSelector<AppState['bookings']>('bookings');
export const getAuthState = createFeatureSelector<AppState['auth']>('auth');
